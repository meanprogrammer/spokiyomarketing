=== My Hello Dolly ===
Contributors: wphigh
Tags: hell dolly, admin notices, funny
Donate link: http://www.wphigh.com
Requires at least: 3.5
Tested up to: 3.9
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin make you custom lyrics, quotes or any other words in the upper right of your admin screen on every page, like Hello Dolly plugin.

== Description ==

This plugin make you custom lyrics, quotes or any other words in the upper right of your admin screen on every page, like Hello Dolly plugin.
[Feedback My Hello Dolly](http://www.wphigh.com/portfolio/my-hello-dolly)

== Screenshots ==
1. admin
2. showcase

== Changelog ==
= 1.0.0 =
* Release.